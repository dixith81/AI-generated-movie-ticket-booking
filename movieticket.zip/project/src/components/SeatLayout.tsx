import React from 'react';
import { motion } from 'framer-motion';

interface SeatProps {
  id: string;
  isSelected: boolean;
  isBooked: boolean;
  onSelect: (id: string) => void;
}

const Seat: React.FC<SeatProps> = ({ id, isSelected, isBooked, onSelect }) => (
  <motion.button
    whileHover={{ scale: 1.1 }}
    whileTap={{ scale: 0.9 }}
    onClick={() => !isBooked && onSelect(id)}
    className={`w-8 h-8 m-1 rounded-t-lg ${
      isBooked
        ? 'bg-gray-600 cursor-not-allowed'
        : isSelected
        ? 'bg-teal-500 hover:bg-teal-600'
        : 'bg-gray-400 hover:bg-gray-500'
    }`}
    disabled={isBooked}
  />
);

interface SeatLayoutProps {
  selectedSeats: string[];
  onSeatSelect: (seatId: string) => void;
  bookedSeats: string[];
}

export function SeatLayout({ selectedSeats, onSeatSelect, bookedSeats }: SeatLayoutProps) {
  const rows = ['A', 'B', 'C', 'D', 'E', 'F', 'G'];
  const seatsPerRow = 12;

  return (
    <div className="w-full max-w-4xl mx-auto">
      {/* Screen */}
      <div className="relative mb-12">
        <div className="w-full h-2 bg-gray-300 rounded-lg transform -skew-y-6"></div>
        <p className="text-center text-gray-400 mt-4">Screen</p>
      </div>

      {/* Seat Layout */}
      <div className="space-y-4">
        {rows.map((row) => (
          <div key={row} className="flex items-center">
            <span className="w-6 text-gray-400">{row}</span>
            <div className="flex flex-1 justify-center gap-2">
              {Array.from({ length: seatsPerRow }, (_, i) => {
                const seatId = `${row}${i + 1}`;
                return (
                  <Seat
                    key={seatId}
                    id={seatId}
                    isSelected={selectedSeats.includes(seatId)}
                    isBooked={bookedSeats.includes(seatId)}
                    onSelect={onSeatSelect}
                  />
                );
              })}
            </div>
            <span className="w-6 text-gray-400">{row}</span>
          </div>
        ))}
      </div>

      {/* Legend */}
      <div className="flex justify-center items-center gap-8 mt-8">
        <div className="flex items-center gap-2">
          <div className="w-6 h-6 bg-gray-400 rounded-t-lg"></div>
          <span className="text-gray-400">Available</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-6 h-6 bg-teal-500 rounded-t-lg"></div>
          <span className="text-gray-400">Selected</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-6 h-6 bg-gray-600 rounded-t-lg"></div>
          <span className="text-gray-400">Booked</span>
        </div>
      </div>
    </div>
  );
}