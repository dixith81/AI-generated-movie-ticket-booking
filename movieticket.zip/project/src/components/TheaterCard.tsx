import React from 'react';
import { MapPin, Clock } from 'lucide-react';
import { Theater } from '../types/movie';

interface TheaterCardProps {
  theater: Theater;
  onSelectTime: (time: string) => void;
}

export function TheaterCard({ theater, onSelectTime }: TheaterCardProps) {
  return (
    <div className="bg-gray-900 rounded-lg p-6 shadow-xl">
      <h3 className="text-xl font-bold text-white mb-2">{theater.name}</h3>
      <div className="flex items-center text-gray-400 mb-4">
        <MapPin size={16} className="mr-2" />
        <span>{theater.location} ({theater.distance})</span>
      </div>
      <div className="space-y-2">
        <div className="flex items-center text-gray-400 mb-2">
          <Clock size={16} className="mr-2" />
          <span>Available Showtimes:</span>
        </div>
        <div className="grid grid-cols-3 gap-2">
          {theater.showTimes.map((time) => (
            <button
              key={time}
              onClick={() => onSelectTime(time)}
              className="bg-gray-800 hover:bg-teal-600 text-white py-2 px-3 rounded-md text-sm transition-colors"
            >
              {time}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}