import React, { useState, useEffect, useRef } from 'react';
import { Search } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { FEATURED_MOVIES } from '../utils/mockData';
import { useNavigate } from 'react-router-dom';

export function SearchBar() {
  const [query, setQuery] = useState('');
  const [suggestions, setSuggestions] = useState<typeof FEATURED_MOVIES>([]);
  const [isOpen, setIsOpen] = useState(false);
  const navigate = useNavigate();
  const wrapperRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (wrapperRef.current && !wrapperRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSearch = (value: string) => {
    setQuery(value);
    
    if (value.length > 1) {
      const filtered = FEATURED_MOVIES.filter(movie =>
        movie.title.toLowerCase().includes(value.toLowerCase()) ||
        movie.genre.some(g => g.toLowerCase().includes(value.toLowerCase()))
      );
      setSuggestions(filtered);
      setIsOpen(true);
    } else {
      setSuggestions([]);
      setIsOpen(false);
    }
  };

  const handleSelect = (movieId: string) => {
    setIsOpen(false);
    setQuery('');
    navigate(`/movie/${movieId}`);
  };

  return (
    <div ref={wrapperRef} className="relative max-w-2xl mx-auto">
      <div className="relative">
        <div className="absolute inset-y-0 left-3 flex items-center pointer-events-none">
          <Search className="h-5 w-5 text-gray-400" />
        </div>
        <input
          type="text"
          value={query}
          onChange={(e) => handleSearch(e.target.value)}
          placeholder="Search for movies by title or genre..."
          className="w-full pl-10 pr-4 py-3 bg-gray-800 dark:bg-gray-100 text-white dark:text-gray-900 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-600 placeholder-gray-400 dark:placeholder-gray-500"
        />
      </div>
      
      <AnimatePresence>
        {isOpen && suggestions.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="absolute top-full left-0 right-0 mt-2 bg-gray-800 dark:bg-white rounded-lg shadow-xl z-50 overflow-hidden"
          >
            {suggestions.map((movie) => (
              <motion.button
                key={movie.id}
                whileHover={{ backgroundColor: 'rgba(0,0,0,0.1)' }}
                onClick={() => handleSelect(movie.id)}
                className="w-full text-left px-4 py-3 flex items-center gap-3 text-white dark:text-gray-900"
              >
                <img
                  src={movie.imageUrl}
                  alt={movie.title}
                  className="w-12 h-12 object-cover rounded"
                />
                <div>
                  <p className="font-medium">{movie.title}</p>
                  <p className="text-sm text-gray-400 dark:text-gray-500">
                    {movie.genre.join(', ')}
                  </p>
                </div>
              </motion.button>
            ))}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}