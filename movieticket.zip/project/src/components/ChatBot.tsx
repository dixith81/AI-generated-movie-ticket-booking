import React, { useState, useEffect, useRef } from 'react';
import { MessageCircle, X, Send } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { getMovieSuggestions } from '../utils/aiUtils';
import { useNavigate } from 'react-router-dom';

interface Message {
  text: string;
  isBot: boolean;
  id: string;
  links?: { text: string; url: string }[];
}

export function ChatBot() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    { 
      text: "Hello! I'm your AI movie assistant. I can help you find movies, get recommendations, and book tickets. How can I help you today?",
      isBot: true,
      id: '1'
    }
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const navigate = useNavigate();

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim()) return;
    
    const userMessage = { text: input, isBot: false, id: Date.now().toString() };
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsTyping(true);

    try {
      const response = getMovieSuggestions(input);
      
      // Check for booking links in the response
      const bookingMatch = response.match(/\/book\/(\w+)/);
      const message: Message = {
        text: response.replace(/\/book\/\w+/, ''),
        isBot: true,
        id: Date.now().toString()
      };
      
      if (bookingMatch) {
        message.links = [{
          text: 'Book Now',
          url: `/book/${bookingMatch[1]}`
        }];
      }
      
      setMessages(prev => [...prev, message]);
    } catch (error) {
      setMessages(prev => [...prev, { 
        text: "I'm sorry, I'm having trouble processing your request right now. Please try again later.",
        isBot: true,
        id: Date.now().toString()
      }]);
    }
    
    setIsTyping(false);
  };

  const handleLink = (url: string) => {
    setIsOpen(false);
    navigate(url);
  };

  return (
    <>
      <motion.button
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
        onClick={() => setIsOpen(true)}
        className="fixed bottom-4 right-4 bg-teal-600 text-white p-4 rounded-full shadow-lg hover:bg-teal-700 transition-colors"
      >
        <MessageCircle size={24} />
      </motion.button>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            className="fixed bottom-20 right-4 w-96 bg-gray-900 rounded-lg shadow-xl"
          >
            <div className="flex justify-between items-center p-4 border-b border-gray-800">
              <h3 className="text-white font-bold">AI Movie Assistant</h3>
              <motion.button
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                onClick={() => setIsOpen(false)}
                className="text-gray-400 hover:text-white"
              >
                <X size={20} />
              </motion.button>
            </div>
            
            <div className="h-[500px] overflow-y-auto p-4 space-y-4">
              {messages.map((msg) => (
                <motion.div
                  key={msg.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className={`flex ${msg.isBot ? 'justify-start' : 'justify-end'}`}
                >
                  <div
                    className={`max-w-[80%] p-3 rounded-lg ${
                      msg.isBot
                        ? 'bg-gray-800 text-white'
                        : 'bg-teal-600 text-white'
                    }`}
                  >
                    <div className="whitespace-pre-line">{msg.text}</div>
                    {msg.links && (
                      <div className="mt-2 space-x-2">
                        {msg.links.map((link, index) => (
                          <button
                            key={index}
                            onClick={() => handleLink(link.url)}
                            className="bg-teal-500 hover:bg-teal-600 text-white px-3 py-1 rounded-md text-sm transition-colors"
                          >
                            {link.text}
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                </motion.div>
              ))}
              {isTyping && (
                <div className="flex justify-start">
                  <div className="bg-gray-800 text-white p-3 rounded-lg">
                    <motion.div
                      animate={{ opacity: [0.4, 1, 0.4] }}
                      transition={{ duration: 1.5, repeat: Infinity }}
                    >
                      Typing...
                    </motion.div>
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>

            <div className="p-4 border-t border-gray-800">
              <div className="flex gap-2">
                <input
                  type="text"
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleSend()}
                  placeholder="Ask about movies..."
                  className="flex-1 bg-gray-800 text-white rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-teal-600"
                />
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={handleSend}
                  className="bg-teal-600 text-white p-2 rounded-lg hover:bg-teal-700 transition-colors"
                >
                  <Send size={20} />
                </motion.button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}