import React from 'react';
import { Search, Ticket, MapPin } from 'lucide-react';

interface SearchSuggestionsProps {
  query: string;
  suggestions: {
    movies: string[];
    theaters: string[];
  };
  onSelect: (value: string, type: 'movie' | 'theater') => void;
}

export function SearchSuggestions({ query, suggestions, onSelect }: SearchSuggestionsProps) {
  if (!query) return null;

  return (
    <div className="absolute top-full left-0 right-0 mt-2 bg-gray-900 rounded-lg shadow-xl z-50">
      {suggestions.movies.length > 0 && (
        <div className="p-2">
          <div className="text-gray-400 text-sm px-3 py-2">Movies</div>
          {suggestions.movies.map((movie) => (
            <button
              key={movie}
              onClick={() => onSelect(movie, 'movie')}
              className="w-full text-left px-3 py-2 hover:bg-gray-800 rounded-lg flex items-center gap-2 text-white"
            >
              <Ticket size={16} />
              <span>{movie}</span>
            </button>
          ))}
        </div>
      )}

      {suggestions.theaters.length > 0 && (
        <div className="p-2 border-t border-gray-800">
          <div className="text-gray-400 text-sm px-3 py-2">Theaters</div>
          {suggestions.theaters.map((theater) => (
            <button
              key={theater}
              onClick={() => onSelect(theater, 'theater')}
              className="w-full text-left px-3 py-2 hover:bg-gray-800 rounded-lg flex items-center gap-2 text-white"
            >
              <MapPin size={16} />
              <span>{theater}</span>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}