import React from 'react';
import { Star, Clock, Calendar } from 'lucide-react';
import { Movie } from '../types/movie';

interface MovieDetailsProps {
  movie: Movie;
  onBook: () => void;
}

export function MovieDetails({ movie, onBook }: MovieDetailsProps) {
  return (
    <div className="bg-gray-900 rounded-lg overflow-hidden shadow-xl">
      <div className="relative h-96">
        <img 
          src={movie.imageUrl} 
          alt={movie.title} 
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-gray-900 to-transparent" />
      </div>
      <div className="p-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-3xl font-bold text-white">{movie.title}</h2>
          <div className="flex items-center bg-yellow-500 text-black px-3 py-1 rounded-full">
            <Star size={16} className="mr-1" />
            <span className="font-bold">{movie.rating}</span>
          </div>
        </div>
        
        <div className="flex items-center gap-6 text-gray-400 mb-6">
          <div className="flex items-center">
            <Clock size={16} className="mr-2" />
            <span>{movie.duration}</span>
          </div>
          <div className="flex items-center">
            <Calendar size={16} className="mr-2" />
            <span>{movie.releaseDate}</span>
          </div>
        </div>

        <p className="text-gray-300 mb-6">{movie.synopsis}</p>
        
        <div className="flex flex-wrap gap-2 mb-6">
          {movie.genre.map((genre) => (
            <span 
              key={genre}
              className="bg-gray-800 text-gray-300 px-3 py-1 rounded-full text-sm"
            >
              {genre}
            </span>
          ))}
        </div>

        <button
          onClick={onBook}
          className="w-full bg-teal-600 hover:bg-teal-700 text-white font-bold py-3 px-6 rounded-lg transition-colors"
        >
          Book Tickets
        </button>
      </div>
    </div>
  );
}