import React from 'react';
import { Star } from 'lucide-react';

interface FeedbackFormProps {
  movieId: string;
  movieTitle: string;
}

export function FeedbackForm({ movieId, movieTitle }: FeedbackFormProps) {
  const [rating, setRating] = React.useState(0);
  const [comment, setComment] = React.useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle feedback submission
    console.log({ movieId, rating, comment });
    setRating(0);
    setComment('');
  };

  return (
    <div className="bg-gray-900 rounded-lg p-6 shadow-xl">
      <h3 className="text-xl font-bold text-white mb-4">Rate "{movieTitle}"</h3>
      
      <div className="flex items-center space-x-2 mb-4">
        {[1, 2, 3, 4, 5].map((star) => (
          <button
            key={star}
            onClick={() => setRating(star)}
            className={`p-1 rounded-full transition-colors ${
              star <= rating ? 'text-yellow-500' : 'text-gray-400'
            }`}
          >
            <Star size={24} fill={star <= rating ? 'currentColor' : 'none'} />
          </button>
        ))}
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <textarea
            value={comment}
            onChange={(e) => setComment(e.target.value)}
            placeholder="Share your thoughts about the movie..."
            className="w-full bg-gray-800 text-white rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-teal-600"
            rows={4}
          />
        </div>

        <button
          type="submit"
          className="w-full bg-teal-600 hover:bg-teal-700 text-white font-bold py-2 px-4 rounded-lg transition-colors"
        >
          Submit Review
        </button>
      </form>
    </div>
  );
}