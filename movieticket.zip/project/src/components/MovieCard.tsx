import React from 'react';
import { Calendar, Clock, Star } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';

interface MovieCardProps {
  id: string;
  title: string;
  rating: number;
  imageUrl: string;
  duration: string;
  releaseDate: string;
}

export function MovieCard({ id, title, rating, imageUrl, duration, releaseDate }: MovieCardProps) {
  const navigate = useNavigate();

  return (
    <div className="bg-gray-900 rounded-lg overflow-hidden shadow-xl transform transition-all hover:scale-105">
      <Link to={`/movie/${id}`}>
        <div className="relative">
          <img 
            src={imageUrl} 
            alt={title} 
            className="w-full h-64 object-cover"
          />
          <div className="absolute top-2 right-2 bg-yellow-500 text-black px-2 py-1 rounded-full flex items-center gap-1">
            <Star size={16} />
            <span className="font-bold">{rating}</span>
          </div>
        </div>
        <div className="p-4">
          <h3 className="text-xl font-bold text-white mb-2">{title}</h3>
          <div className="flex items-center gap-4 text-gray-400 mb-4">
            <div className="flex items-center gap-1">
              <Clock size={16} />
              <span>{duration}</span>
            </div>
            <div className="flex items-center gap-1">
              <Calendar size={16} />
              <span>{releaseDate}</span>
            </div>
          </div>
        </div>
      </Link>
      <div className="px-4 pb-4">
        <button
          onClick={() => navigate(`/book/${id}`)}
          className="w-full bg-teal-600 hover:bg-teal-700 text-white font-bold py-2 px-4 rounded-lg transition-colors"
        >
          Book Tickets
        </button>
      </div>
    </div>
  );
}