import React from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { motion } from 'framer-motion';

interface UpcomingMovie {
  id: string;
  title: string;
  imageUrl: string;
  releaseDate: string;
}

const upcomingMovies: UpcomingMovie[] = [
  {
    id: '1',
    title: 'Captian America: Brave New World',
    imageUrl: 'https://static1.srcdn.com/wordpress/wp-content/uploads/2024/11/captain-america-brave-new-world-official-trailer-bq.jpg',
    releaseDate: 'Feb 14, 2025'
  },
  {
    id: '2',
    title: 'Wolf Man',
    imageUrl: 'https://static1.cbrimages.com/wordpress/wp-content/uploads/sharedimages/2024/11/wolf-man-2025-film-new-poster.jpg',
    releaseDate: 'Jan 17, 2025'
  },
  {
    id: '3',
    title: 'Den Of Thieves 2: Pantera',
    imageUrl: 'https://preview.redd.it/official-poster-for-den-of-thieves-2-pantera-starring-v0-8ggrubwxelpd1.jpeg?width=640&crop=smart&auto=webp&s=e918ae1acc218aeed84fc6c02fd92fc1bffa295c',
    releaseDate: 'jan 10, 2025'
  },
  {
    id: '4',
    title: 'A Minecraft Movie',
    imageUrl: 'https://www.minecraft.net/content/dam/minecraftnet/franchise/photography/things/AMM%20Hero%20Visual%20Bee%20-%201170x500.jpg.jpg',
    releaseDate: 'Apr 04, 2025'
  }
];

export function UpcomingMovies() {
  const scrollRef = React.useRef<HTMLDivElement>(null);

  const scroll = (direction: 'left' | 'right') => {
    if (scrollRef.current) {
      const scrollAmount = 300;
      scrollRef.current.scrollBy({
        left: direction === 'left' ? -scrollAmount : scrollAmount,
        behavior: 'smooth'
      });
    }
  };

  return (
    <div className="relative">
      <h2 className="text-2xl font-bold text-white mb-6">Upcoming Releases</h2>
      
      <div className="relative group">
        <motion.button
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          onClick={() => scroll('left')}
          className="absolute left-0 top-1/2 -translate-y-1/2 bg-gray-900/80 p-2 rounded-full z-10 opacity-0 group-hover:opacity-100 transition-opacity"
        >
          <ChevronLeft className="text-white" />
        </motion.button>

        <div
          ref={scrollRef}
          className="flex gap-6 overflow-x-auto scrollbar-hide scroll-smooth pb-4"
        >
          {upcomingMovies.map((movie, index) => (
            <motion.div
              key={movie.id}
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.2 }}
              whileHover={{ scale: 1.05 }}
              className="flex-none w-72 bg-gray-900 rounded-lg overflow-hidden shadow-xl"
            >
              <motion.img
                whileHover={{ scale: 1.1 }}
                transition={{ type: "tween" }}
                src={movie.imageUrl}
                alt={movie.title}
                className="w-full h-48 object-cover"
              />
              <div className="p-4">
                <h3 className="text-lg font-semibold text-white mb-2">{movie.title}</h3>
                <p className="text-gray-400">Releasing {movie.releaseDate}</p>
              </div>
            </motion.div>
          ))}
        </div>

        <motion.button
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          onClick={() => scroll('right')}
          className="absolute right-0 top-1/2 -translate-y-1/2 bg-gray-900/80 p-2 rounded-full z-10 opacity-0 group-hover:opacity-100 transition-opacity"
        >
          <ChevronRight className="text-white" />
        </motion.button>
      </div>
    </div>
  );
}