import React from 'react';
import { Filter, SortAsc } from 'lucide-react';

interface FilterProps {
  onFilterChange: (filters: MovieFilters) => void;
  onSortChange: (sort: string) => void;
}

export interface MovieFilters {
  genre?: string;
  language?: string;
  rating?: number;
}

const genres = ['Action', 'Drama', 'Comedy', 'Romance', 'Thriller'];
const languages = ['Hindi', 'English', 'Tamil', 'Telugu'];
const sortOptions = ['Most Popular', 'Latest Releases', 'Top Rated'];

export function MovieFilters({ onFilterChange, onSortChange }: FilterProps) {
  const [filters, setFilters] = React.useState<MovieFilters>({});
  
  const handleFilterChange = (key: keyof MovieFilters, value: string | number) => {
    const newFilters = { ...filters, [key]: value };
    setFilters(newFilters);
    onFilterChange(newFilters);
  };

  return (
    <div className="bg-gray-900 p-4 rounded-lg space-y-4">
      <div className="flex items-center gap-2 text-white mb-4">
        <Filter size={20} />
        <h3 className="font-semibold">Filters</h3>
      </div>

      <div className="space-y-4">
        <div>
          <label className="block text-gray-400 mb-2">Genre</label>
          <select
            onChange={(e) => handleFilterChange('genre', e.target.value)}
            className="w-full bg-gray-800 text-white rounded-lg p-2 focus:outline-none focus:ring-2 focus:ring-teal-600"
          >
            <option value="">All Genres</option>
            {genres.map((genre) => (
              <option key={genre} value={genre}>{genre}</option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-gray-400 mb-2">Language</label>
          <select
            onChange={(e) => handleFilterChange('language', e.target.value)}
            className="w-full bg-gray-800 text-white rounded-lg p-2 focus:outline-none focus:ring-2 focus:ring-teal-600"
          >
            <option value="">All Languages</option>
            {languages.map((language) => (
              <option key={language} value={language}>{language}</option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-gray-400 mb-2">
            <div className="flex items-center gap-2">
              <SortAsc size={20} />
              <span>Sort By</span>
            </div>
          </label>
          <select
            onChange={(e) => onSortChange(e.target.value)}
            className="w-full bg-gray-800 text-white rounded-lg p-2 focus:outline-none focus:ring-2 focus:ring-teal-600"
          >
            {sortOptions.map((option) => (
              <option key={option} value={option}>{option}</option>
            ))}
          </select>
        </div>
      </div>
    </div>
  );
}