export interface Movie {
  id: string;
  title: string;
  rating: number;
  imageUrl: string;
  duration: string;
  releaseDate: string;
  synopsis: string;
  genre: string[];
}

export interface Theater {
  id: string;
  name: string;
  location: string;
  distance: string;
  showTimes: string[];
}

export interface BookingDetails {
  movieId: string;
  theaterId: string;
  showTime: string;
  seats: string[];
  totalPrice: number;
}