import { FEATURED_MOVIES } from './mockData';
import type { Movie } from '../types/movie';

function getMoviesByGenre(genre: string): Movie[] {
  return FEATURED_MOVIES.filter(movie => 
    movie.genre.some(g => g.toLowerCase() === genre.toLowerCase())
  );
}

function formatMovieRecommendation(movie: Movie): string {
  return `
${movie.title} (Rating: ${movie.rating}/10)
🎬 ${movie.genre.join(', ')}
⏱️ ${movie.duration}
📅 ${movie.releaseDate}

${movie.synopsis}

You can book tickets for this movie by clicking the "Book Tickets" button or typing "book ${movie.title}".
`;
}

export function getMovieSuggestions(userInput: string): string {
  const input = userInput.toLowerCase();
  
  // Handle genre-based recommendations
  const genreMatch = input.match(/(?:recommend|suggest|show|find).*(?:movies?|films?) (?:in|for|about) ([\w\s]+)/i);
  if (genreMatch) {
    const genre = genreMatch[1].trim();
    const movies = getMoviesByGenre(genre);
    
    if (movies.length === 0) {
      return `I couldn't find any ${genre} movies right now. Would you like to try another genre? We have Action, Drama, Comedy, Romance, and Thriller movies.`;
    }
    
    const recommendations = movies.map(formatMovieRecommendation).join('\n\n');
    return `Here are some ${genre} movies you might enjoy:\n\n${recommendations}`;
  }
  
  // Handle booking requests
  const bookingMatch = input.match(/book\s+(.+)/i);
  if (bookingMatch) {
    const movieTitle = bookingMatch[1].trim();
    const movie = FEATURED_MOVIES.find(m => 
      m.title.toLowerCase().includes(movieTitle.toLowerCase())
    );
    
    if (movie) {
      return `Great choice! I'll help you book tickets for ${movie.title}. You can proceed to the booking page by clicking here: /book/${movie.id}`;
    } else {
      return `I couldn't find a movie called "${movieTitle}". Could you please check the title and try again?`;
    }
  }
  
  // Handle general queries
  if (input.includes('help') || input.includes('what can you do')) {
    return `I can help you with:
1. Finding movies by genre (e.g., "recommend action movies")
2. Booking tickets (e.g., "book Dunki")
3. Getting movie information
4. Finding show times

Just let me know what you're interested in!`;
  }
  
  if (input.includes('show') && input.includes('time')) {
    return `To check show times, please select a movie first. You can ask me to recommend movies or search for a specific title.`;
  }
  
  // Default response
  return `I'm here to help you find and book movies! You can:
- Ask for movie recommendations by genre
- Book tickets for a specific movie
- Ask about show times
- Get movie information

What would you like to do?`;
}