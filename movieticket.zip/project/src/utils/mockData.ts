import { Movie, Theater } from '../types/movie';

export const FEATURED_MOVIES: Movie[] = [
  {
    id: '1',
    title: 'Pushpa 2',
    rating: 6.8,
    imageUrl:
      'https://m.media-amazon.com/images/M/MV5BYWE5ZDZiNmYtZjI0Mi00MDY0LWJkMmMtYWU2MjcyNDNiZjA4XkEyXkFqcGdeQXRyYW5zY29kZS13b3JrZmxvdw@@._V1_QL75_UX500_CR0,0,500,281_.jpg',
    duration: '2h 40m',
    releaseDate: 'December 5, 2024',
    synopsis:
      ' Pushpa, the red sandalwood smuggler, faces off against his rival SP Bhanwar Singh Shekhawat in an epic showdown, with the stakes higher than ever as he navigates a complex web of politics and crime.',
    genre: ['Crime', 'Drama', 'Action'],
  },
  {
    id: '2',
    title: 'Lucky Bhaskar',
    rating: 8.2,
    imageUrl: 'https://static.tnn.in/photo/msid-114812919/114812919.jpg',
    duration: '2h 31m',
    releaseDate: 'October 21, 2024',
    synopsis:
      'A cash-strapped cashier working at a bank embarks on a risky investment scheme and soon gets drawn into the murky world of money laundering.',
    genre: ['Crime', 'Drama', 'Thriller'],
  },
  {
    id: '3',
    title: 'Dunki',
    rating: 8.2,
    imageUrl:
      'https://www.hindustantimes.com/ht-img/img/2024/02/15/550x309/dunki_1699090816204_1707969495323.jfif',
    duration: '2h 41m',
    releaseDate: 'December 21, 2023',
    synopsis:
      'A heartwarming tale about four friends and their quest to reach foreign shores, Dunki is a saga of love and friendship that brings together these wildly disparate stories.',
    genre: ['Comedy', 'Drama', 'Adventure'],
  },
  {
    id: '4',
    title: 'Animal',
    rating: 8.4,
    imageUrl:
      'https://www.looper.com/img/gallery/animal-2023-why-the-controversial-bollywood-movie-is-getting-destroyed-by-critics/what-exactly-is-animal-1702779147.jpg',
    duration: '3h 21m',
    releaseDate: 'December 1, 2023',
    synopsis:
      'A son undergoes a remarkable transformation as the bond with his father begins to fracture, leading him down a dark path of vengeance and destruction.',
    genre: ['Action', 'Crime', 'Drama'],
  },
  {
    id: '5',
    title: '12th Fail',
    rating: 9.2,
    imageUrl:
      'https://media.themoviedb.org/t/p/w533_and_h300_bestv2/4njfDPI3VeNPyHwWYYdPruU9MDk.jpg',
    duration: '2h 27m',
    releaseDate: 'October 27, 2023',
    synopsis:
      "Based on a true story, follows IPS officer Manoj Kumar Sharma and IRS officer Shraddha Joshi's journey of success through hard work and determination.",
    genre: ['Drama', 'Biography'],
  },
];

export const NEARBY_THEATERS: Theater[] = [
  {
    id: '1',
    name: 'PVR: Nexus Mall, Pandeshwar, Mangalore',
    location:
      'Nexus Mall, 2nd Floor, Cantonment Ward, Pandeshwar Road, Attavar, Mangaluru (Mangalore), Karnataka 575001, India',
    distance: '1.2 km',
    showTimes: ['10:30 AM', '1:15 PM', '4:00 PM', '7:30 PM', '10:15 PM'],
  },
  {
    id: '2',
    name: 'Cinepolis: City Centre Mall, Mangaluru',
    location: 'K S Rao Road, Hampankatta, Mangalore, Karnataka 122002, India',
    distance: '2.5 km',
    showTimes: ['11:00 AM', '2:00 PM', '5:00 PM', '8:00 PM', '10:45 PM'],
  },
  {
    id: '3',
    name: 'Bharath Cinemas: Bharath Mall, Bejai, Mangaluru',
    location:
      'Bharath Mall, Opp K.S.R.T.C, Bejai Kavoor Road, Mangalore, Karnataka 575013, India',
    distance: '3 km',
    showTimes: ['11:00 AM', '2:00 PM', '5:00 PM', '8:00 PM', '10:45 PM'],
  },
  {
    id: '4',
    name: 'Cine Galaxy: Surathkal, Mangalore',
    location:
      '3rd Floor, Abish Business Centre, Maarigudi Road, Near - Chawadi Banquet Hall, Mangaluru (Mangalore), Karnataka 575014, India',
    distance: '5 km',
    showTimes: ['10:30 AM', '1:15 PM', '4:00 PM', '7:30 PM', '10:15 PM'],
  },
];
