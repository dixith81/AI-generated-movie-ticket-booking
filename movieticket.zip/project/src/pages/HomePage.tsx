import React from 'react';
import { SearchBar } from '../components/SearchBar';
import { MovieCard } from '../components/MovieCard';
import { MovieFilters } from '../components/MovieFilters';
import { UpcomingMovies } from '../components/UpcomingMovies';
import { FEATURED_MOVIES } from '../utils/mockData';
import { motion } from 'framer-motion';

export function HomePage() {
  const [filteredMovies, setFilteredMovies] = React.useState(FEATURED_MOVIES);

  const handleFilterChange = (filters: any) => {
    let movies = [...FEATURED_MOVIES];
    
    if (filters.genre) {
      movies = movies.filter(movie => movie.genre.includes(filters.genre));
    }
    
    setFilteredMovies(movies);
  };

  const handleSort = (sortBy: string) => {
    let movies = [...filteredMovies];
    
    switch (sortBy) {
      case 'Most Popular':
        movies.sort((a, b) => b.rating - a.rating);
        break;
      case 'Latest Releases':
        movies.sort((a, b) => new Date(b.releaseDate).getTime() - new Date(a.releaseDate).getTime());
        break;
      default:
        break;
    }
    
    setFilteredMovies(movies);
  };

  return (
    <div className="min-h-screen bg-gray-950">
      {/* Hero Section with Search and Filters */}
      <div className="bg-gradient-to-b from-gray-900 to-gray-950 py-20">
        <div className="container mx-auto px-4">
          <motion.h1 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-4xl md:text-5xl font-bold text-center mb-8 text-white"
          >
            Book Your Perfect Movie Experience
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.2 }}
            className="text-gray-400 text-center mb-8 max-w-2xl mx-auto"
          >
            Find and book tickets for the latest Bollywood and Hollywood movies.
            Get personalized recommendations and instant support.
          </motion.p>
          
          <div className="max-w-4xl mx-auto">
            <SearchBar />
            <div className="mt-6">
              <MovieFilters 
                onFilterChange={handleFilterChange}
                onSortChange={handleSort}
              />
            </div>
          </div>
        </div>
      </div>

      {/* Upcoming Movies */}
      <div className="container mx-auto px-4 py-12">
        <UpcomingMovies />
      </div>

      {/* Featured Movies Grid */}
      <div className="container mx-auto px-4 py-12">
        <h2 className="text-2xl font-bold mb-8 text-white">Featured Movies</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredMovies.map((movie, index) => (
            <motion.div
              key={movie.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <MovieCard
                id={movie.id}
                title={movie.title}
                rating={movie.rating}
                imageUrl={movie.imageUrl}
                duration={movie.duration}
                releaseDate={movie.releaseDate}
                onBook={() => {}}
              />
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}