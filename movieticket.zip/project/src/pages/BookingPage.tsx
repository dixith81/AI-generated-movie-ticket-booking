import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { SeatLayout } from '../components/SeatLayout';
import { FEATURED_MOVIES } from '../utils/mockData';

export function BookingPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [selectedSeats, setSelectedSeats] = useState<string[]>([]);
  const movie = FEATURED_MOVIES.find(m => m.id === id);
  
  // Simulate some random booked seats
  const bookedSeats = ['A1', 'A2', 'B5', 'C7', 'D3', 'E8', 'F4', 'G10'];
  const ticketPrice = 250; // Price per ticket in INR

  const handleSeatSelect = (seatId: string) => {
    setSelectedSeats(prev =>
      prev.includes(seatId)
        ? prev.filter(id => id !== seatId)
        : [...prev, seatId]
    );
  };

  const handleBooking = () => {
    if (selectedSeats.length === 0) {
      alert('Please select at least one seat');
      return;
    }
    
    // Here you would typically make an API call to process the booking
    alert(`Booking confirmed for seats: ${selectedSeats.join(', ')}`);
    navigate('/');
  };

  if (!movie) {
    return (
      <div className="min-h-screen bg-gray-950 flex items-center justify-center">
        <p className="text-white">Movie not found</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-950 py-12">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-4xl mx-auto"
        >
          {/* Movie Info */}
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-white mb-2">{movie.title}</h1>
            <div className="flex gap-4 text-gray-400">
              <span>{movie.duration}</span>
              <span>•</span>
              <span>{movie.releaseDate}</span>
            </div>
          </div>

          {/* Seat Selection */}
          <div className="bg-gray-900 rounded-lg p-8 mb-8">
            <SeatLayout
              selectedSeats={selectedSeats}
              onSeatSelect={handleSeatSelect}
              bookedSeats={bookedSeats}
            />
          </div>

          {/* Booking Summary */}
          <div className="bg-gray-900 rounded-lg p-6">
            <h2 className="text-xl font-bold text-white mb-4">Booking Summary</h2>
            <div className="space-y-4">
              <div className="flex justify-between text-gray-400">
                <span>Selected Seats</span>
                <span>{selectedSeats.length ? selectedSeats.join(', ') : 'None'}</span>
              </div>
              <div className="flex justify-between text-gray-400">
                <span>Price per Ticket</span>
                <span>₹{ticketPrice}</span>
              </div>
              <div className="flex justify-between text-gray-400">
                <span>Convenience Fee</span>
                <span>₹{selectedSeats.length * 20}</span>
              </div>
              <div className="border-t border-gray-800 pt-4">
                <div className="flex justify-between text-white font-bold">
                  <span>Total Amount</span>
                  <span>₹{selectedSeats.length * (ticketPrice + 20)}</span>
                </div>
              </div>
            </div>

            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={handleBooking}
              disabled={selectedSeats.length === 0}
              className={`w-full mt-6 py-3 rounded-lg font-bold transition-colors ${
                selectedSeats.length > 0
                  ? 'bg-teal-600 hover:bg-teal-700 text-white'
                  : 'bg-gray-600 text-gray-400 cursor-not-allowed'
              }`}
            >
              {selectedSeats.length > 0 ? 'Proceed to Payment' : 'Select Seats to Continue'}
            </motion.button>
          </div>
        </motion.div>
      </div>
    </div>
  );
}