import React, { useState, useEffect } from 'react';
import { MapPin } from 'lucide-react';
import { TheaterCard } from '../components/TheaterCard';
import { NEARBY_THEATERS } from '../utils/mockData';

export function TheatersPage() {
  const [location, setLocation] = useState('');
  const [isLocating, setIsLocating] = useState(false);

  const handleGetLocation = () => {
    setIsLocating(true);
    if ('geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          // In a real app, we would use these coordinates to fetch nearby theaters
          console.log(position.coords.latitude, position.coords.longitude);
          setIsLocating(false);
        },
        (error) => {
          console.error('Error getting location:', error);
          setIsLocating(false);
        }
      );
    }
  };

  return (
    <div className="min-h-screen bg-gray-950 py-12">
      <div className="container mx-auto px-4">
        <div className="max-w-2xl mx-auto mb-12">
          <h1 className="text-3xl font-bold text-white mb-6">Find Theaters Near You</h1>
          
          <div className="flex gap-4 mb-8">
            <input
              type="text"
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              placeholder="Enter your location..."
              className="flex-1 bg-gray-800 text-white px-4 py-2 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-600"
            />
            <button
              onClick={handleGetLocation}
              disabled={isLocating}
              className="bg-teal-600 hover:bg-teal-700 text-white px-6 py-2 rounded-lg flex items-center gap-2 transition-colors"
            >
              <MapPin size={20} />
              {isLocating ? 'Locating...' : 'Use My Location'}
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {NEARBY_THEATERS.map((theater) => (
            <TheaterCard
              key={theater.id}
              theater={theater}
              onSelectTime={(time) => console.log('Selected time:', time)}
            />
          ))}
        </div>
      </div>
    </div>
  );
}