import React, { useState } from 'react';
import { LoginForm, RegisterForm } from '../components/AuthForms';

export function AuthPage() {
  const [isLogin, setIsLogin] = useState(true);

  return (
    <div className="min-h-screen bg-gray-950 py-20">
      <div className="container mx-auto px-4">
        <div className="max-w-md mx-auto bg-gray-900 rounded-lg shadow-xl p-8">
          <div className="flex justify-center mb-8">
            <div className="inline-flex rounded-lg">
              <button
                className={`px-4 py-2 rounded-l-lg ${
                  isLogin
                    ? 'bg-teal-600 text-white'
                    : 'bg-gray-800 text-gray-400'
                }`}
                onClick={() => setIsLogin(true)}
              >
                Login
              </button>
              <button
                className={`px-4 py-2 rounded-r-lg ${
                  !isLogin
                    ? 'bg-teal-600 text-white'
                    : 'bg-gray-800 text-gray-400'
                }`}
                onClick={() => setIsLogin(false)}
              >
                Register
              </button>
            </div>
          </div>

          {isLogin ? <LoginForm /> : <RegisterForm />}
        </div>
      </div>
    </div>
  );
}