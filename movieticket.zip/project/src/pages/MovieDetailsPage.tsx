import React from 'react';
import { useParams } from 'react-router-dom';
import { MovieDetails } from '../components/MovieDetails';
import { TheaterCard } from '../components/TheaterCard';
import { FeedbackForm } from '../components/FeedbackForm';
import { FEATURED_MOVIES, NEARBY_THEATERS } from '../utils/mockData';

export function MovieDetailsPage() {
  const { id } = useParams();
  const movie = FEATURED_MOVIES.find(m => m.id === id);

  if (!movie) {
    return (
      <div className="min-h-screen bg-gray-950 flex items-center justify-center">
        <p className="text-white">Movie not found</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-950 py-12">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Movie Details */}
          <div className="lg:col-span-2">
            <MovieDetails 
              movie={movie} 
              onBook={() => console.log('Book clicked')} 
            />
          </div>

          {/* Feedback Form */}
          <div>
            <FeedbackForm 
              movieId={movie.id} 
              movieTitle={movie.title} 
            />
          </div>
        </div>

        {/* Nearby Theaters */}
        <div className="mt-12">
          <h2 className="text-2xl font-bold text-white mb-6">Nearby Theaters</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {NEARBY_THEATERS.map((theater) => (
              <TheaterCard
                key={theater.id}
                theater={theater}
                onSelectTime={(time) => console.log('Selected time:', time)}
              />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}