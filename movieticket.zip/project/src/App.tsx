import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Header } from './components/Header';
import { HomePage } from './pages/HomePage';
import { AuthPage } from './pages/AuthPage';
import { MovieDetailsPage } from './pages/MovieDetailsPage';
import { TheatersPage } from './pages/TheatersPage';
import { BookingPage } from './pages/BookingPage';
import { ChatBot } from './components/ChatBot';
import { ThemeProvider } from './contexts/ThemeContext';

function App() {
  return (
    <ThemeProvider>
      <Router>
        <div className="min-h-screen bg-white dark:bg-gray-950 text-gray-900 dark:text-white transition-colors duration-200">
          <Header />
          
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/login" element={<AuthPage />} />
            <Route path="/movie/:id" element={<MovieDetailsPage />} />
            <Route path="/theaters" element={<TheatersPage />} />
            <Route path="/book/:id" element={<BookingPage />} />
          </Routes>

          <ChatBot />
        </div>
      </Router>
    </ThemeProvider>
  );
}

export default App;